package com.example.activitease;

public class Notification {
    private double[] notification;

    private int hour;
    private int minute;
    private int second;

    public Notification(int hour, int minute, int second){
        this.hour = hour;
        this.minute = minute;
        this.second = second;
    }

    public int getHour(){ return this.hour; }
    public int getMinute(){ return this.minute; }
    public int getSecond(){ return this.second; }

    public String getFormatTime(){
        return String.valueOf(hour + ":" + minute + ":" + second);
    }

    /*

    public double[] getNotificationTime(Interest interest){

        double[] notification_time = null;
        for(int j = 0; j < interest.getNotifTimes().length; j++){
            notification_time[j] = interest.getNotifTimes()[j];
        }

        String firstInterestName = interest.getInterestName();
        return notification_time;
    }


    public void setNotification(Interest interest){
        double[] n_time = getNotificationTime(interest);

        for(int i = 0; i < n_time.length; i++){
            this.hour[i] = (int) n_time[i];
            this.minute[i] = (int) n_time[i] * 60 % 60;
            this.second[i] = (int) n_time[i] * 60 * 60 % 3600;
        }
    }
    */

}

/*


    public ArrayList<Double[]> getNotificationTime(ArrayList<Interest> interest){
        ArrayList<Double[]> notification_times = new ArrayList<Double[]>();
        double[] notification_time = null;

        List<Interest> interestList = MainActivity.myDB.myDao().getInterests();
        for (int i = 0; i < interest.size(); i++) {

            for(int j = 0; j < interestList.get(i).getNotifTimes().length; j++){
                notification_time[j] = interestList.get(i).getNotifTimes()[i];
            }
        }

        String firstInterestName = interestList.get(0).getInterestName();

        return notification_times;
    }


    public void setNotification(Interest interest){
        ArrayList<Double[]> ntime = getNotificationTime()
        int hour;
        int minute;
        int second;
    }

 */