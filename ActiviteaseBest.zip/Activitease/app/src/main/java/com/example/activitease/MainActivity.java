package com.example.activitease;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.arch.persistence.room.Room;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.content.Intent;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.Calendar;
import java.util.List;

import static java.lang.String.format;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener
{
    EditText interestName, periodFrequency, basePeriodSpan, activityLength, numNotifications;
    static String currentInterestName;
    String startStopTimerText;
    public final String CHANNEL_ID = "Personal Notification";
    private final int NOTIFICATION_ID = 001;


    public static MyDB myDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        FragmentTransaction hp = getSupportFragmentManager().beginTransaction();
        hp.replace(R.id.fragment_container, new Home_Page_Fragment());
        hp.commit();


        setContentView(R.layout.activity_main);

        // Code to create notifications for android 8.0+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Personal Notifications";
            String description = "Include all the personal notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;

            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, name, importance);

            notificationChannel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(notificationChannel);


        }

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        /**
         Initializes the Room database object.
         Database is called 'interestdb'.
         */
        myDB = Room.databaseBuilder(getApplicationContext(), MyDB.class, "interestdb")
                .allowMainThreadQueries().build();

        makeNotifications();


    }
    public void makeNotifications(){
        // Setting up intents for notification alarms--------------------------------------

        Calendar c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();
        Calendar c3 = Calendar.getInstance();
        Calendar c4 = Calendar.getInstance();
        Calendar c5 = Calendar.getInstance();
        Calendar c6 = Calendar.getInstance();
        Calendar c7 = Calendar.getInstance();
        Calendar c8 = Calendar.getInstance();
        Calendar c9 = Calendar.getInstance();
        Calendar c10 = Calendar.getInstance();

        List<Interest> interestList = MainActivity.myDB.myDao().getInterests();
        Intent intent = new Intent(getApplicationContext(), Notification_receiver.class);
        Intent intent2 = new Intent(getApplicationContext(), Notification_receiver2.class);
        Intent intent3 = new Intent(getApplicationContext(), Notification_receiver3.class);
        Intent intent4 = new Intent(getApplicationContext(), Notification_receiver4.class);
        Intent intent5 = new Intent(getApplicationContext(), Notification_receiver5.class);

        PendingIntent pendingIntent1_1 = PendingIntent.getBroadcast(getApplicationContext(), 1011, intent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent1_2 = PendingIntent.getBroadcast(getApplicationContext(), 1012, intent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent1_3 = PendingIntent.getBroadcast(getApplicationContext(), 1013, intent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent1_4 = PendingIntent.getBroadcast(getApplicationContext(), 1014, intent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent1_5 = PendingIntent.getBroadcast(getApplicationContext(), 1015, intent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent2_1 = PendingIntent.getBroadcast(getApplicationContext(), 1021, intent2,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent2_2 = PendingIntent.getBroadcast(getApplicationContext(), 1022, intent2,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent2_3 = PendingIntent.getBroadcast(getApplicationContext(), 1023, intent2,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent2_4 = PendingIntent.getBroadcast(getApplicationContext(), 1024, intent2,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent2_5 = PendingIntent.getBroadcast(getApplicationContext(), 1025, intent2,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent3_1 = PendingIntent.getBroadcast(getApplicationContext(), 1031, intent3,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent3_2 = PendingIntent.getBroadcast(getApplicationContext(), 1032, intent3,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent3_3 = PendingIntent.getBroadcast(getApplicationContext(), 1033, intent3,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent3_4 = PendingIntent.getBroadcast(getApplicationContext(), 1034, intent3,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent3_5 = PendingIntent.getBroadcast(getApplicationContext(), 1035, intent3,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent4_1 = PendingIntent.getBroadcast(getApplicationContext(), 1041, intent4,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent4_2 = PendingIntent.getBroadcast(getApplicationContext(), 1042, intent4,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent4_3 = PendingIntent.getBroadcast(getApplicationContext(), 1043, intent4,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent4_4 = PendingIntent.getBroadcast(getApplicationContext(), 1044, intent4,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent4_5 = PendingIntent.getBroadcast(getApplicationContext(), 1045, intent4,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent5_1 = PendingIntent.getBroadcast(getApplicationContext(), 1051, intent5,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent5_2 = PendingIntent.getBroadcast(getApplicationContext(), 1052, intent5,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent5_3 = PendingIntent.getBroadcast(getApplicationContext(), 1053, intent5,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent5_4 = PendingIntent.getBroadcast(getApplicationContext(), 1054, intent5,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent5_5 = PendingIntent.getBroadcast(getApplicationContext(), 1055, intent5,
                PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);


        // Array for storing number of notifications

        int[] notifications = new int[10];
        int k = 0;

        for (Interest intr : interestList) {
            if (intr != null) {

                notifications[k] = intr.getNumNotifications();

                k++;
            } else
                break;

        }
        // If notification # for interest 1 = __
        if (notifications[0] == 0) {
            // Do nothing
        }
        if (notifications[0] == 1) {
            c1.set(Calendar.HOUR_OF_DAY, 15);   // Set hour for notification
            c1.set(Calendar.MINUTE, 45);        // Set minute for notification
            checkTime(c1);                      // Add a day if time has already passed
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent1_1);
        }
        if (notifications[0] == 2) {
            //
            c1.set(Calendar.HOUR_OF_DAY, 14);
            c1.set(Calendar.MINUTE, 50);
            checkTime(c1);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent1_1);
            c1.set(Calendar.HOUR_OF_DAY, 14);
            c1.set(Calendar.MINUTE, 52);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent1_2);
        }
        if (notifications[0] == 3) {
            c1.set(Calendar.HOUR_OF_DAY, 12);
            c1.set(Calendar.MINUTE, 22);
            checkTime(c1);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent1_1);
            c1.set(Calendar.HOUR_OF_DAY, 15);
            c1.set(Calendar.MINUTE, 45);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent1_2);
            c1.set(Calendar.HOUR_OF_DAY, 19);
            c1.set(Calendar.MINUTE, 07);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent1_3);
        }
        if (notifications[0] == 4) {
            c1.set(Calendar.HOUR_OF_DAY, 11);
            c1.set(Calendar.MINUTE, 42);
            checkTime(c1);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent1_1);
            c1.set(Calendar.HOUR_OF_DAY, 14);
            c1.set(Calendar.MINUTE, 24);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent1_2);
            c1.set(Calendar.HOUR_OF_DAY, 17);
            c1.set(Calendar.MINUTE, 06);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent1_3);
            c1.set(Calendar.HOUR_OF_DAY, 19);
            c1.set(Calendar.MINUTE, 48);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent1_4);
        }
        if (notifications[0] == 5) {
            c2.set(Calendar.HOUR_OF_DAY, 11);
            c2.set(Calendar.MINUTE, 15);
            checkTime(c2);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent1_1);
            c2.set(Calendar.HOUR_OF_DAY, 13);
            c2.set(Calendar.MINUTE, 30);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent1_2);
            c2.set(Calendar.HOUR_OF_DAY, 15);
            c2.set(Calendar.MINUTE, 45);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent1_3);
            c2.set(Calendar.HOUR_OF_DAY, 18);
            c2.set(Calendar.MINUTE, 00);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent1_4);
            c2.set(Calendar.HOUR_OF_DAY, 20);
            c2.set(Calendar.MINUTE, 15);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent1_5);
        }
        if (notifications[1] == 0) {
            // Do nothing
        }
        if (notifications[1] == 1) {
            c2.set(Calendar.HOUR_OF_DAY, 15);   // Set hour for notification
            c2.set(Calendar.MINUTE, 45);        // Set minute for notification
            checkTime(c2);                      // Add a day if time has already passed
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent2_1);
        }
        if (notifications[1] == 2) {
            c2.set(Calendar.HOUR_OF_DAY, 14);
            c2.set(Calendar.MINUTE, 50);
            checkTime(c2);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent2_1);
            c2.set(Calendar.HOUR_OF_DAY, 14);
            c2.set(Calendar.MINUTE, 52);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent2_2);
        }
        if (notifications[1] == 3) {
            c2.set(Calendar.HOUR_OF_DAY, 12);
            c2.set(Calendar.MINUTE, 22);
            checkTime(c2);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent2_1);
            c2.set(Calendar.HOUR_OF_DAY, 15);
            c2.set(Calendar.MINUTE, 45);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent2_2);
            c2.set(Calendar.HOUR_OF_DAY, 19);
            c2.set(Calendar.MINUTE, 07);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent2_3);
        }
        if (notifications[1] == 4) {
            c2.set(Calendar.HOUR_OF_DAY, 11);
            c2.set(Calendar.MINUTE, 42);
            checkTime(c2);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent2_1);
            c2.set(Calendar.HOUR_OF_DAY, 14);
            c2.set(Calendar.MINUTE, 24);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent2_2);
            c2.set(Calendar.HOUR_OF_DAY, 17);
            c2.set(Calendar.MINUTE, 06);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent2_3);
            c2.set(Calendar.HOUR_OF_DAY, 19);
            c2.set(Calendar.MINUTE, 48);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent2_4);
        }
        if (notifications[1] == 5) {
            c2.set(Calendar.HOUR_OF_DAY, 11);
            c2.set(Calendar.MINUTE, 15);
            checkTime(c2);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent2_1);
            c2.set(Calendar.HOUR_OF_DAY, 13);
            c2.set(Calendar.MINUTE, 30);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent2_2);
            c2.set(Calendar.HOUR_OF_DAY, 15);
            c2.set(Calendar.MINUTE, 45);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent2_3);
            c2.set(Calendar.HOUR_OF_DAY, 18);
            c2.set(Calendar.MINUTE, 00);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent2_4);
            c2.set(Calendar.HOUR_OF_DAY, 20);
            c2.set(Calendar.MINUTE, 15);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent2_5);
        }
        if (notifications[2] == 0) {
            // Do nothing
        }
        if (notifications[2] == 1) {
            c3.set(Calendar.HOUR_OF_DAY, 15);   // Set hour for notification
            c3.set(Calendar.MINUTE, 45);        // Set minute for notification
            checkTime(c3);                      // Add a day if time has already passed
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c3.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent3_1);
        }
        if (notifications[2] == 2) {
            c3.set(Calendar.HOUR_OF_DAY, 14);
            c3.set(Calendar.MINUTE, 50);
            checkTime(c3);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c3.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent3_1);
            c3.set(Calendar.HOUR_OF_DAY, 14);
            c3.set(Calendar.MINUTE, 52);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c3.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent3_2);
        }
        if (notifications[2] == 3) {
            c3.set(Calendar.HOUR_OF_DAY, 12);
            c3.set(Calendar.MINUTE, 22);
            checkTime(c3);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c3.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent3_1);
            c3.set(Calendar.HOUR_OF_DAY, 15);
            c3.set(Calendar.MINUTE, 45);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c3.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent3_2);
            c3.set(Calendar.HOUR_OF_DAY, 19);
            c3.set(Calendar.MINUTE, 07);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c3.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent3_3);
        }
        if (notifications[2] == 4) {
            c3.set(Calendar.HOUR_OF_DAY, 11);
            c3.set(Calendar.MINUTE, 42);
            checkTime(c3);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c3.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent3_1);
            c3.set(Calendar.HOUR_OF_DAY, 14);
            c3.set(Calendar.MINUTE, 24);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c3.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent3_2);
            c3.set(Calendar.HOUR_OF_DAY, 17);
            c3.set(Calendar.MINUTE, 06);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c3.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent3_3);
            c3.set(Calendar.HOUR_OF_DAY, 19);
            c3.set(Calendar.MINUTE, 48);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c3.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent3_4);
        }
        if (notifications[2] == 5) {
            c3.set(Calendar.HOUR_OF_DAY, 11);
            c3.set(Calendar.MINUTE, 15);
            checkTime(c3);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c3.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent3_1);
            c3.set(Calendar.HOUR_OF_DAY, 13);
            c3.set(Calendar.MINUTE, 30);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c3.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent3_2);
            c3.set(Calendar.HOUR_OF_DAY, 15);
            c3.set(Calendar.MINUTE, 45);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c3.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent3_3);
            c3.set(Calendar.HOUR_OF_DAY, 18);
            c3.set(Calendar.MINUTE, 00);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c3.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent3_4);
            c3.set(Calendar.HOUR_OF_DAY, 20);
            c3.set(Calendar.MINUTE, 15);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c3.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent3_5);
        }
        if (notifications[3] == 0) {
            // Do nothing
        }
        if (notifications[3] == 1) {
            c4.set(Calendar.HOUR_OF_DAY, 15);   // Set hour for notification
            c4.set(Calendar.MINUTE, 45);        // Set minute for notification
            checkTime(c4);                      // Add a day if time has already passed
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c4.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent4_1);
        }
        if (notifications[3] == 2) {
            c4.set(Calendar.HOUR_OF_DAY, 15);
            c4.set(Calendar.MINUTE, 20);
            checkTime(c4);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c4.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent4_1);
            c4.set(Calendar.HOUR_OF_DAY, 15);
            c4.set(Calendar.MINUTE, 22);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c4.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent4_2);
        }
        if (notifications[3] == 3) {
            c4.set(Calendar.HOUR_OF_DAY, 12);
            c4.set(Calendar.MINUTE, 22);
            checkTime(c4);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c4.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent4_1);
            c4.set(Calendar.HOUR_OF_DAY, 15);
            c4.set(Calendar.MINUTE, 45);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c4.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent4_2);
            c4.set(Calendar.HOUR_OF_DAY, 19);
            c4.set(Calendar.MINUTE, 07);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c4.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent4_3);
        }
        if (notifications[3] == 4) {
            c4.set(Calendar.HOUR_OF_DAY, 11);
            c4.set(Calendar.MINUTE, 42);
            checkTime(c4);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c4.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent4_1);
            c4.set(Calendar.HOUR_OF_DAY, 14);
            c4.set(Calendar.MINUTE, 24);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c4.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent4_2);
            c4.set(Calendar.HOUR_OF_DAY, 17);
            c4.set(Calendar.MINUTE, 06);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c4.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent4_3);
            c4.set(Calendar.HOUR_OF_DAY, 19);
            c4.set(Calendar.MINUTE, 48);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c4.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent4_4);
        }
        if (notifications[3] == 5) {
            c4.set(Calendar.HOUR_OF_DAY, 11);
            c4.set(Calendar.MINUTE, 15);
            checkTime(c4);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c4.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent4_1);
            c4.set(Calendar.HOUR_OF_DAY, 13);
            c4.set(Calendar.MINUTE, 30);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c4.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent4_2);
            c4.set(Calendar.HOUR_OF_DAY, 15);
            c4.set(Calendar.MINUTE, 45);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c4.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent4_3);
            c4.set(Calendar.HOUR_OF_DAY, 18);
            c4.set(Calendar.MINUTE, 00);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c4.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent4_4);
            c4.set(Calendar.HOUR_OF_DAY, 20);
            c4.set(Calendar.MINUTE, 15);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c4.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent4_5);
        }
        if (notifications[4] == 0) {
            // Do nothing
        }
        if (notifications[4] == 1) {
            c5.set(Calendar.HOUR_OF_DAY, 15);   // Set hour for notification
            c5.set(Calendar.MINUTE, 45);        // Set minute for notification
            checkTime(c5);                      // Add a day if time has already passed
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c5.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent5_1);
        }
        if (notifications[4] == 2) {
            c5.set(Calendar.HOUR_OF_DAY, 15);
            c5.set(Calendar.MINUTE, 7);
            checkTime(c5);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c5.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent5_1);
            c5.set(Calendar.HOUR_OF_DAY, 15);
            c5.set(Calendar.MINUTE, 9);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c5.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent5_2);
        }
        if (notifications[4] == 3) {
            c5.set(Calendar.HOUR_OF_DAY, 12);
            c5.set(Calendar.MINUTE, 22);
            checkTime(c5);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c5.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent5_1);
            c5.set(Calendar.HOUR_OF_DAY, 15);
            c5.set(Calendar.MINUTE, 45);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c5.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent5_2);
            c5.set(Calendar.HOUR_OF_DAY, 19);
            c5.set(Calendar.MINUTE, 07);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c5.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent5_3);
        }
        if (notifications[4] == 4) {
            c5.set(Calendar.HOUR_OF_DAY, 11);
            c5.set(Calendar.MINUTE, 42);
            checkTime(c5);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c5.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent5_1);
            c5.set(Calendar.HOUR_OF_DAY, 14);
            c5.set(Calendar.MINUTE, 24);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c5.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent5_2);
            c5.set(Calendar.HOUR_OF_DAY, 17);
            c5.set(Calendar.MINUTE, 06);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c5.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent5_3);
            c5.set(Calendar.HOUR_OF_DAY, 19);
            c5.set(Calendar.MINUTE, 48);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c5.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent5_4);
        }
        if (notifications[4] == 5) {
            c5.set(Calendar.HOUR_OF_DAY, 11);
            c5.set(Calendar.MINUTE, 15);
            checkTime(c5);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c5.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent5_1);
            c5.set(Calendar.HOUR_OF_DAY, 13);
            c5.set(Calendar.MINUTE, 30);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c5.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent5_2);
            c5.set(Calendar.HOUR_OF_DAY, 15);
            c5.set(Calendar.MINUTE, 45);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c5.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent5_3);
            c5.set(Calendar.HOUR_OF_DAY, 18);
            c5.set(Calendar.MINUTE, 00);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c5.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent5_4);
            c5.set(Calendar.HOUR_OF_DAY, 20);
            c5.set(Calendar.MINUTE, 15);
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c5.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent5_5);
        }
    }

    // Function tr check if alarm time is passed
    public Calendar checkTime(Calendar c) {
        if (c.before(Calendar.getInstance())) {
            c.add(Calendar.DATE, 1);
        }
        return c;
    }
    
    public void notifyMe(View view) {
        NotificationCompat.Builder builder = new
                NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setContentTitle("Simple Notification")
                .setWhen(System.currentTimeMillis())
                .setContentText("This is a simple notification")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity
                (this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setContentIntent(pendingIntent);

        NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(this);
        notificationManagerCompat.notify(NOTIFICATION_ID, builder.build());

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if(id == R.id.homePage) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new Home_Page_Fragment()).commit();
        }
        else if (id == R.id.FAQ) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new FAQ_Fragment()).commit();

        }
//        else if (id == R.id.Interest) {
//            getSupportFragmentManager().beginTransaction()
//                    .replace(R.id.fragment_container, new Interest_Fragment()).commit();
//        }
        else if (id == R.id.About) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new About_Fragment()).commit();
        }
        else if (id == R.id.Setting) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new Settings_Fragment()).commit();
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    public void openAddInterest(View view)
    {
        FragmentTransaction hp = getSupportFragmentManager().beginTransaction();
        hp.replace(R.id.fragment_container, new Add_Interest_Fragment());
        hp.commit();
    }

    public void openInterest(View view)
    {
        //Loads the button that the method was called from.
        Button interestB = (Button)view;

        // Name of the interest found from the text of the button.
        String interestName = (String)interestB.getText();
        // Trims the button text to the interest name, which will be used to trigger db pull.
        interestName = interestName.substring(0, interestName.indexOf(" "));
        // Loads the interest, using the interest name as the key.
        Interest thisInterest = MainActivity.myDB.myDao().loadInterestByName(interestName);
        currentInterestName = thisInterest.getInterestName();

        FragmentTransaction hp = getSupportFragmentManager().beginTransaction();
        Interest_Fragment populatedInterest = new Interest_Fragment();

        /*
            Initializes variables in the Interest_Fragment object, which will then be used
            once the Interest_Fragment's onCreateView method is activated.
         */
        populatedInterest.setButtonText("Start Activity");
        populatedInterest.initializeInterest(thisInterest.getInterestName());
        /*
            pSpanPtr is the pointer for the Spinner selection.
            0 for day (1), 1 for week (7), 2 for month (30), 3 for year(365, or else in this case).
         */
        if (thisInterest.getBasePeriodSpan() == 1) populatedInterest.setpSpanPtr(0);
        else if (thisInterest.getBasePeriodSpan() == 7) populatedInterest.setpSpanPtr(1);
        else if (thisInterest.getBasePeriodSpan() == 30) populatedInterest.setpSpanPtr(2);
        else populatedInterest.setpSpanPtr(3);

        populatedInterest.setNumNotif(thisInterest.getNumNotifications());

        hp.replace(R.id.fragment_container, populatedInterest);
        hp.commit();
    }
    
    public void openAct1(View view)
    {


        FragmentTransaction hp = getSupportFragmentManager().beginTransaction();
        hp.replace(R.id.fragment_container, new Interest_Fragment());
        hp.commit();

        //myAwesomeTextView = (TextView)findViewById(R.id.actText);
        //myAwesomeTextView.setText("50 Push-Ups");

    }

    public void doneBtn(View view)  //When done button pressed, update interest and reload page.
    {
        Button b = (Button) view;
        Interest_Fragment resetTimer = new Interest_Fragment();
        resetTimer.resetTimer();
        FragmentTransaction hp = getSupportFragmentManager().beginTransaction();
        resetTimer.setTimerRunning(false);
        Interest updatedInterest = MainActivity.myDB.myDao().loadInterestByName(currentInterestName);
        resetTimer.initializeInterest(updatedInterest.getInterestName());
        resetTimer.setButtonText("Start Activity");
        GLRenderer.setTimerRunning(false);
        GLRenderer.setNumIterations(updatedInterest.getNumIterations());


        hp.replace(R.id.fragment_container, resetTimer);
        hp.commit();

    }

    public void startStopTimer(View view) {
        Button b = (Button)view;
        startStopTimerText = b.getText().toString();
        if(startStopTimerText.equals("Start Activity")) {
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Start Activity")
                    .setMessage("Are you sure you want to start this activity?")
                    .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Interest updatedInterest = MainActivity.myDB.myDao().loadInterestByName(currentInterestName);

                            Interest_Fragment updateInterest = new Interest_Fragment();
                            updateInterest.setTimerRunning(true);
                            FragmentTransaction hp = getSupportFragmentManager().beginTransaction();
                            updateInterest.initializeInterest(updatedInterest.getInterestName());
                            GLRenderer.setNumIterations(updatedInterest.getNumIterations());
                            updateInterest.setButtonText("Pause");

                            hp.replace(R.id.fragment_container, updateInterest);
                            hp.commit();
                        }

                    })
                    .setNegativeButton("no", null)
                    .show();
        }
        else if(startStopTimerText.equals("Pause")) {

            Interest updatedInterest = MainActivity.myDB.myDao().loadInterestByName(currentInterestName);
            Interest_Fragment updateInterest = new Interest_Fragment();
            updateInterest.pauseTimer();
            FragmentTransaction hp = getSupportFragmentManager().beginTransaction();
            updateInterest.setTimerRunning(false);
            updateInterest.initializeInterest(updatedInterest.getInterestName());
            updateInterest.setButtonText("Start Activity");
            GLRenderer.setNumIterations(updatedInterest.getNumIterations());

            hp.replace(R.id.fragment_container, updateInterest);

             hp.commit();

            //Update timer. Update DB with new interest data
        }

    }

    public static int getInterestTableSz() {
        return MainActivity.myDB.myDao().getInterests().size();
    }

  /*  public void openContactPage(View view)
    {
        startActivity(new Intent(getApplicationContext(), ContactManager.class));
        //getSupportFragmentManager().beginTransaction().
        // replace(R.id.fragment_container, new Contact()).commit();
    } */

}
