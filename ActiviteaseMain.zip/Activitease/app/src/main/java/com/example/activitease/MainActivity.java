package com.example.activitease;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.arch.persistence.room.Room;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.content.Intent;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener
{
    EditText interestName, periodFrequency, basePeriodSpan, activityLength, numNotifications;
    static String currentInterestName;
    String startStopTimerText;
    public final String CHANNEL_ID = "Personal Notification";
    private final int NOTIFICATION_ID = 001;


    public static MyDB myDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        FragmentTransaction hp = getSupportFragmentManager().beginTransaction();
        hp.replace(R.id.fragment_container, new Home_Page_Fragment());
        hp.commit();



        setContentView(R.layout.activity_main);

        // Code to create notifications for android 8.0+
        if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.O) {
            CharSequence name = "Personal Notifications";
            String description = "Include all the personal notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;

            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, name, importance);

            notificationChannel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(notificationChannel);


        }


        Calendar c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();

        // Notfication start time
        c1.set(Calendar.HOUR_OF_DAY, 15);
        c1.set(Calendar.MINUTE, 42);
        c1.set(Calendar.SECOND, 00);

        // Notification end time
        c2.set(Calendar.HOUR_OF_DAY, 22);
        c2.set(Calendar.MINUTE, 25);
        c2.set(Calendar.SECOND, 00);


        Intent intent = new Intent(getApplicationContext(), Notification_receiver.class);
        Intent intent2 = new Intent(getApplicationContext(), Notification_receiver2.class);
        Intent intent3 = new Intent(getApplicationContext(), Notification_receiver3.class);
        Intent intent4 = new Intent(getApplicationContext(), Notification_receiver4.class);
        Intent intent5 = new Intent(getApplicationContext(), Notification_receiver5.class);
        Intent intent6 = new Intent(getApplicationContext(), Notification_receiver6.class);
        Intent intent7 = new Intent(getApplicationContext(), Notification_receiver7.class);
        Intent intent8 = new Intent(getApplicationContext(), Notification_receiver8.class);
        Intent intent9 = new Intent(getApplicationContext(), Notification_receiver9.class);
        Intent intent10 = new Intent(getApplicationContext(), Notification_receiver10.class);
        Intent cancellationIntent = new Intent(getApplicationContext(), CancelAlarmBroadcastReceiver.class);



        PendingIntent pendingIntent1 = PendingIntent.getBroadcast(getApplicationContext(), 101, intent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent2 = PendingIntent.getBroadcast(getApplicationContext(), 102, intent2,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent3 = PendingIntent.getBroadcast(getApplicationContext(), 103, intent3,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent4 = PendingIntent.getBroadcast(getApplicationContext(), 104, intent4,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent5 = PendingIntent.getBroadcast(getApplicationContext(), 105, intent5,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent6 = PendingIntent.getBroadcast(getApplicationContext(), 106, intent6,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent7 = PendingIntent.getBroadcast(getApplicationContext(), 107, intent7,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent8 = PendingIntent.getBroadcast(getApplicationContext(), 108, intent8,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent9 = PendingIntent.getBroadcast(getApplicationContext(), 109, intent9,
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent pendingIntent10 = PendingIntent.getBroadcast(getApplicationContext(), 110, intent10,
                PendingIntent.FLAG_UPDATE_CURRENT);



        PendingIntent cancellationPendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 101, cancellationIntent, PendingIntent.FLAG_CANCEL_CURRENT);

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        AlarmManager alarmManager2 = (AlarmManager) getSystemService(ALARM_SERVICE);
        if (c1.before(Calendar.getInstance())) {
            c1.add(Calendar.DATE, 1);
        }

        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), 1000*60, pendingIntent1);
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent2);
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent3);
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent4);
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent5);
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent6);
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent7);
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent8);
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent9);
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, c1.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent10);
        alarmManager.set(AlarmManager.RTC_WAKEUP, c2.getTimeInMillis(),cancellationPendingIntent);

        // End of Notification Code


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);



        /**
         Initializes the Room database object.
         Database is called 'interestdb'.
         */
        myDB = Room.databaseBuilder(getApplicationContext(), MyDB.class, "interestdb")
                .allowMainThreadQueries().build();
    }
    
    public void notifyMe(View view) {
        NotificationCompat.Builder builder = new
                NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setContentTitle("Simple Notification")
                .setWhen(System.currentTimeMillis())
                .setContentText("This is a simple notification")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity
                (this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setContentIntent(pendingIntent);

        NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(this);
        notificationManagerCompat.notify(NOTIFICATION_ID, builder.build());

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if(id == R.id.homePage) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new Home_Page_Fragment()).commit();
        }
        else if (id == R.id.FAQ) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new FAQ_Fragment()).commit();

        }
//        else if (id == R.id.Interest) {
//            getSupportFragmentManager().beginTransaction()
//                    .replace(R.id.fragment_container, new Interest_Fragment()).commit();
//        }
        else if (id == R.id.About) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new About_Fragment()).commit();
        }
        else if (id == R.id.Setting) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new Settings_Fragment()).commit();
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    public void openAddInterest(View view)
    {
        FragmentTransaction hp = getSupportFragmentManager().beginTransaction();
        hp.replace(R.id.fragment_container, new Add_Interest_Fragment());
        hp.commit();
    }

    public void openInterest(View view)
    {
        //Loads the button that the method was called from.
        Button interestB = (Button)view;

        // Name of the interest found from the text of the button.
        String interestName = (String)interestB.getText();
        // Trims the button text to the interest name, which will be used to trigger db pull.
        interestName = interestName.substring(0, interestName.indexOf(" "));
        // Loads the interest, using the interest name as the key.
        Interest thisInterest = MainActivity.myDB.myDao().loadInterestByName(interestName);
        currentInterestName = thisInterest.getInterestName();

        FragmentTransaction hp = getSupportFragmentManager().beginTransaction();
        Interest_Fragment populatedInterest = new Interest_Fragment();

        /*
            Initializes variables in the Interest_Fragment object, which will then be used
            once the Interest_Fragment's onCreateView method is activated.
         */
        populatedInterest.setButtonText("Start Activity");
        populatedInterest.initializeInterest(thisInterest.getInterestName());
        /*
            pSpanPtr is the pointer for the Spinner selection.
            0 for day (1), 1 for week (7), 2 for month (30), 3 for year(365, or else in this case).
         */
        if (thisInterest.getBasePeriodSpan() == 1) populatedInterest.setpSpanPtr(0);
        else if (thisInterest.getBasePeriodSpan() == 7) populatedInterest.setpSpanPtr(1);
        else if (thisInterest.getBasePeriodSpan() == 30) populatedInterest.setpSpanPtr(2);
        else populatedInterest.setpSpanPtr(3);

        populatedInterest.setNumNotif(thisInterest.getNumNotifications());

        hp.replace(R.id.fragment_container, populatedInterest);
        hp.commit();
    }
    
    public void openAct1(View view)
    {


        FragmentTransaction hp = getSupportFragmentManager().beginTransaction();
        hp.replace(R.id.fragment_container, new Interest_Fragment());
        hp.commit();

        //myAwesomeTextView = (TextView)findViewById(R.id.actText);
        //myAwesomeTextView.setText("50 Push-Ups");

    }

    public void doneBtn(View view)  //When done button pressed, update interest and reload page.
    {
        Button b = (Button) view;
        Interest_Fragment resetTimer = new Interest_Fragment();
        resetTimer.resetTimer();
        FragmentTransaction hp = getSupportFragmentManager().beginTransaction();
        resetTimer.setTimerRunning(false);
        Interest updatedInterest = MainActivity.myDB.myDao().loadInterestByName(currentInterestName);
        resetTimer.initializeInterest(updatedInterest.getInterestName());
        resetTimer.setButtonText("Start Activity");
        GLRenderer.setTimerRunning(false);
        GLRenderer.setNumIterations(updatedInterest.getNumIterations());


        hp.replace(R.id.fragment_container, resetTimer);
        hp.commit();

    }

    public void startStopTimer(View view) {
        Button b = (Button)view;
        startStopTimerText = b.getText().toString();
        if(startStopTimerText.equals("Start Activity")) {
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Start Activity")
                    .setMessage("Are you sure you want to start this activity?")
                    .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Interest updatedInterest = MainActivity.myDB.myDao().loadInterestByName(currentInterestName);

                            Interest_Fragment updateInterest = new Interest_Fragment();
                            updateInterest.setTimerRunning(true);
                            FragmentTransaction hp = getSupportFragmentManager().beginTransaction();
                            updateInterest.initializeInterest(updatedInterest.getInterestName());
                            GLRenderer.setNumIterations(updatedInterest.getNumIterations());
                            updateInterest.setButtonText("Pause");

                            hp.replace(R.id.fragment_container, updateInterest);
                            hp.commit();
                        }

                    })
                    .setNegativeButton("no", null)
                    .show();
        }
        else if(startStopTimerText.equals("Pause")) {

            Interest updatedInterest = MainActivity.myDB.myDao().loadInterestByName(currentInterestName);
            Interest_Fragment updateInterest = new Interest_Fragment();
            updateInterest.pauseTimer();
            FragmentTransaction hp = getSupportFragmentManager().beginTransaction();
            updateInterest.setTimerRunning(false);
            updateInterest.initializeInterest(updatedInterest.getInterestName());
            updateInterest.setButtonText("Start Activity");
            GLRenderer.setNumIterations(updatedInterest.getNumIterations());

            hp.replace(R.id.fragment_container, updateInterest);

             hp.commit();

            //Update timer. Update DB with new interest data
        }

    }

    public static int getInterestTableSz() {
        return MainActivity.myDB.myDao().getInterests().size();
    }

  /*  public void openContactPage(View view)
    {
        startActivity(new Intent(getApplicationContext(), ContactManager.class));
        //getSupportFragmentManager().beginTransaction().
        // replace(R.id.fragment_container, new Contact()).commit();
    } */

}
