package com.example.activitease;


import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;

import java.util.List;

public class Notification_receiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {

        List<Interest> interestList = MainActivity.myDB.myDao().getInterests();
        int numOfInterest = interestList.size();

        for (int i = 0; i < numOfInterest; i++) {
            System.out.println(interestList.get(i).getInterestName());
        }

        String firstInterestName = interestList.get(0).getInterestName();


        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        Intent repeating_intent = new Intent(context, MainActivity.class);
        repeating_intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);


        PendingIntent pendingIntent = PendingIntent.getActivity(context, 100, repeating_intent, PendingIntent.FLAG_UPDATE_CURRENT);

        int icon = R.mipmap.ic_launcher;

        NotificationCompat.Builder builder1 = new NotificationCompat.Builder(context)
                .setContentIntent(pendingIntent)
                //.setSmallIcon(android.R.drawable.arrow_up_float)setSmallIcon(icon);
                .setSmallIcon(icon)
                .setContentTitle(firstInterestName)
                .setContentText("Number of Notification")
                .setWhen(System.currentTimeMillis())
                .setAutoCancel(true);
        notificationManager.notify(100, builder1.build());


        NotificationManager notificationManager1 = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        Intent repeating_intent1 = new Intent(context, MainActivity.class);
        repeating_intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pendingIntent1 = PendingIntent.getActivity(context, 101, repeating_intent1, PendingIntent.FLAG_UPDATE_CURRENT);
        int icon1 = R.mipmap.ic_launcher;

        NotificationCompat.Builder builder2 = new NotificationCompat.Builder(context)
                .setContentIntent(pendingIntent)
                //.setSmallIcon(android.R.drawable.arrow_up_float)setSmallIcon(icon);
                .setSmallIcon(icon1)
                .setContentTitle("new question")
                .setContentText("You have a new message !")
                .setWhen(System.currentTimeMillis())
                .setAutoCancel(true);
        notificationManager.notify(101, builder2.build());

    }

}
