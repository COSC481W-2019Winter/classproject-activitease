package com.example.activitease;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FriendsManager extends AppCompatActivity {

    DatabaseHelper friendsDb;
    Button btnAddData, btnViewData, btnUpdateData, btnDelete;
    EditText etNewFriend, etInterest, etTime, etID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends_manager);

        etNewFriend = (EditText) findViewById(R.id.etNewFriend);
        etInterest = (EditText) findViewById(R.id.etInterest);
        etID = (EditText) findViewById(R.id.etID);
        etTime = (EditText) findViewById(R.id.etTime);

        btnAddData = (Button)findViewById(R.id.btnAddData);
        btnViewData = (Button)findViewById(R.id.btnViewData);
        btnUpdateData = (Button)findViewById(R.id.btnUpdateData);
        btnDelete = (Button)findViewById(R.id.btnDelete);

        friendsDb = new DatabaseHelper(this);

        AddData();
        ViewData();
        UpdateData();
        DeleteData();
    }

    public void AddData(){
        btnAddData.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String interest = etInterest.getText().toString();
                String friend = etNewFriend.getText().toString();
                String time = etTime.getText().toString(); //int time = etTime.getText().Integer.valueOf(toString());


                boolean insertData = friendsDb.addData(friend, interest, time);

                if(insertData == true){
                    Toast.makeText(FriendsManager.this, "Data Successfully Inserted!", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(FriendsManager.this, "Something went wrong :(.", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void ViewData(){
        btnViewData.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v) {
                Cursor data = friendsDb.getListContents();

                if (data.getCount() == 0) {
                    display("Error", "No Data found.");
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (data.moveToNext()) {
                    buffer.append("ID: " + data.getString(0) + "\n");
                    buffer.append("Friend's Name: " + data.getString(1) + "\n");
                    buffer.append("Interests List: " + data.getString(2) + "\n");

                    display("All your friends here!", buffer.toString());
                }
            }
        });
    }

    public void UpdateData(){
        btnUpdateData.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v) {
                int tmp = etID.getText().toString().length();
                if(tmp > 0){
                    boolean update = friendsDb.updateData(etID.getText().toString(),
                            etNewFriend.getText().toString(),
                            etInterest.getText().toString(),
                            etTime.getText().toString());
                    if(update == true){
                        Toast.makeText(FriendsManager.this, "Successfully Update Data!", Toast.LENGTH_LONG).show();
                    }else{
                        Toast.makeText(FriendsManager.this, "Something Went Wrong :(.", Toast.LENGTH_LONG).show();
                    }
                }else{
                    Toast.makeText(FriendsManager.this, "You Must Enter An ID to Update :(.", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void DeleteData(){
        btnDelete.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v) {
                int tmp = etID.getText().toString().length();
                if(tmp > 0){
                    Integer deleteRow = friendsDb.deleteData(etID.getText().toString());
                    if(deleteRow > 0){
                        Toast.makeText(FriendsManager.this, "Successfully Deleted The Data!", Toast.LENGTH_LONG).show();
                    }else{
                        Toast.makeText(FriendsManager.this, "Something Went Wrong :(.", Toast.LENGTH_LONG).show();
                    }
                }else{
                    Toast.makeText(FriendsManager.this, "You Must Enter An ID to Delete :(.", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void display(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

}

