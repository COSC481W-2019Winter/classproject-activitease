package com.example.activitease;


import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class Notification_receiver extends BroadcastReceiver {

    private int[][][] hour_minute_second;

    //ArrayList<Integer[]>[] al = new ArrayList[10];
    //List<int[]> myList = new ArrayList<int[]>();
    //ArrayList<Notification> arrayListOfNotification = new ArrayList<Notification>();
    private ArrayList<Notification> arrayListOfNotification = new ArrayList<Notification>();

    private double[] notificationTimes;

    public double[] getNotificationTimes(){
        return  notificationTimes;
    }

    public void onReceive(Context context, Intent intent) {

        List<Interest> interestList = MainActivity.myDB.myDao().getInterests();
        int numOfInterest = interestList.size();

        if(interestList.size() > 0) {

            String firstInterestName = interestList.get(0).getInterestName();
            int numOfNotification = interestList.get(0).getNumNotifications();

            for (int i = 0; i < numOfInterest; i++) {
                ArrayList<Notification> arrayListOfNotification_ = setArrayListOfNotification(interestList.get(i));
                String interestName = interestList.get(i).getInterestName();

                for (Notification noti : arrayListOfNotification_) {
                    int hour = noti.getHour();
                    int minute = noti.getMinute();
                    int second = noti.getSecond();
                    Log.d(interestName, String.valueOf(hour + ":" + minute + ":" + second));
                }
            }

            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

            Intent repeating_intent = new Intent(context, MainActivity.class);
            repeating_intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);


            PendingIntent pendingIntent = PendingIntent.getActivity(context, 100, repeating_intent, PendingIntent.FLAG_UPDATE_CURRENT);

            int icon = R.mipmap.ic_launcher;

            NotificationCompat.Builder builder1 = new NotificationCompat.Builder(context)
                    .setContentIntent(pendingIntent)
                    //.setSmallIcon(android.R.drawable.arrow_up_float)setSmallIcon(icon);
                    .setSmallIcon(icon)
                    .setContentTitle(firstInterestName)
                    .setContentText("Number of Notification")
                    .setWhen(System.currentTimeMillis())
                    .setAutoCancel(true);
            notificationManager.notify(100, builder1.build());


            NotificationManager notificationManager1 = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

            Intent repeating_intent1 = new Intent(context, MainActivity.class);
            repeating_intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

            PendingIntent pendingIntent1 = PendingIntent.getActivity(context, 101, repeating_intent1, PendingIntent.FLAG_UPDATE_CURRENT);
            int icon1 = R.mipmap.ic_launcher;

            NotificationCompat.Builder builder2 = new NotificationCompat.Builder(context)
                    .setContentIntent(pendingIntent)
                    //.setSmallIcon(android.R.drawable.arrow_up_float)setSmallIcon(icon);
                    .setSmallIcon(icon1)
                    .setContentTitle(String.valueOf(numOfNotification))
                    .setContentText("You have a new message !")
                    .setWhen(System.currentTimeMillis())
                    .setAutoCancel(true);
            notificationManager.notify(101, builder2.build());
        }

    }


    private int[] hour;
    private int[] minute;
    private int[] second;

    public double[] getNotificationTime(Interest interest){

        double[] notification_time = null;
        for(int j = 0; j < interest.getNotifTimes().length; j++){
            notification_time[j] = interest.getNotifTimes()[j];
        }

        String firstInterestName = interest.getInterestName();
        return notification_time;
    }


    public ArrayList<Notification> setArrayListOfNotification(Interest interest){
        double[] notificationTimes = interest.getNotifTimes();
        ArrayList<Notification> _arrayListOfNotification = new ArrayList<Notification>();

        for(int j = 0; j < interest.getNumNotifications(); j++){
            int hour = (int) notificationTimes[j];
            int minute = (int) (notificationTimes[j] * 60 % 60);
            int second = (int) (notificationTimes[j] * 60 * 60 % 60);

            Notification notification = new Notification(hour, minute, second);
            _arrayListOfNotification.add(notification);
        }
        return _arrayListOfNotification;
    }

    public ArrayList<Notification> getArrayListOfNotification(Interest interest){
        setArrayListOfNotification(interest);
        return arrayListOfNotification;
    }

}
